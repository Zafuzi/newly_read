# newly_read
Newly Read is a simple modern news site that promises speed and readability. http://newlyread.apphb.com
